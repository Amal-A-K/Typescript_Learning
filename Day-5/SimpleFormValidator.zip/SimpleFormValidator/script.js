(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getUsers = getUsers;
    exports.saveUsers = saveUsers;
    exports.getCurrentUser = getCurrentUser;
    exports.saveCurrentUser = saveCurrentUser;
    function getUsers() {
        return JSON.parse(localStorage.getItem("users") || "[]");
    }
    function saveUsers(users) {
        localStorage.setItem("users", JSON.stringify(users));
    }
    function getCurrentUser() {
        return JSON.parse(localStorage.getItem("user") || "null");
    }
    function saveCurrentUser(user) {
        localStorage.setItem("user", JSON.stringify(user));
    }
});
