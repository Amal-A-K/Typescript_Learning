export type UserRole = "admin" | "editor" | "viewer" | "moderator";

export type User = {
  name: string;
  age: number;
  password: string;
  role: UserRole;
  canEdit: boolean;
  canDelete: boolean;
};

export function getUsers(): User[] {
  return JSON.parse(localStorage.getItem("users") || "[]");
}

export function saveUsers(users: User[]) {
  localStorage.setItem("users", JSON.stringify(users));
}

export function getCurrentUser(): User | null {
  return JSON.parse(localStorage.getItem("user") || "null");
}

export function saveCurrentUser(user: User) {
  localStorage.setItem("user", JSON.stringify(user));
}
