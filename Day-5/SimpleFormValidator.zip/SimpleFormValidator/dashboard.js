(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./script"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const script_1 = require("./script");
    window.addEventListener("DOMContentLoaded", () => {
        const currentUser = (0, script_1.getCurrentUser)();
        const userInfo = document.getElementById("userInfo");
        const userList = document.getElementById("userList");
        if (!currentUser) {
            userInfo.innerHTML = "<p>User not logged in.</p>";
            return;
        }
        userInfo.innerHTML = `
    <h3>Welcome, ${currentUser.name} (${currentUser.role})</h3>
    <ul>
      <li>Can Edit: ${currentUser.canEdit}</li>
      <li>Can Delete: ${currentUser.canDelete}</li>
    </ul>
  `;
        if (currentUser.canEdit) {
            const users = (0, script_1.getUsers)();
            userList.innerHTML = "<h4>All Users</h4>";
            users.forEach((user, index) => {
                const userItem = document.createElement("div");
                userItem.innerHTML = `
        <b>${user.name}</b> (${user.role})
        <button onclick="editUser(${index})">✏️</button>
        <button onclick="deleteUser(${index})">🗑️</button>
      `;
                userList.appendChild(userItem);
            });
            window.editUser = (index) => {
                const users = (0, script_1.getUsers)();
                const u = users[index];
                const newName = prompt("New name:", u.name);
                const newAge = parseInt(prompt("New age:", u.age.toString()) || "", 10);
                const newRole = prompt("New role (admin/editor/viewer/moderator):", u.role);
                if (!newName || isNaN(newAge) || !["admin", "editor", "viewer", "moderator"].includes(newRole)) {
                    alert("Invalid input.");
                    return;
                }
                u.name = newName;
                u.age = newAge;
                u.role = newRole;
                u.canEdit = newRole !== "viewer";
                u.canDelete = newRole === "admin";
                users[index] = u;
                (0, script_1.saveUsers)(users);
                location.reload();
            };
            window.deleteUser = (index) => {
                if (confirm("Are you sure you want to delete this user?")) {
                    const users = (0, script_1.getUsers)();
                    users.splice(index, 1);
                    (0, script_1.saveUsers)(users);
                    location.reload();
                }
            };
        }
    });
});
